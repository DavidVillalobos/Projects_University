# -*- coding: utf-8 -*-

#Importamos algunos modulos

import sys
import os

#Importamos nuestras clases y funciones

from Ataca_a_los_orcos_V1_0_0 import Juego

#CODIGO principal

if __name__ == '__main__':
    game = Juego()
    game.play()
